
this.onmessage = function(e){
  switch(e.data.command){
    case 'encode':
      encode(buffer);
      break;
    case 'decode':
      decode(buffer);
      break;
  }
};

/* Table of index changes */
var IndexTable = [   
    -1, -1, -1, -1, 2, 4, 6, 8,   
    -1, -1, -1, -1, 2, 4, 6, 8   
    ];  
	
/* Quantizer step size lookup table */ 
var StepSizeTable = [   
    7, 8, 9, 10, 11, 12, 13, 14, 16, 17,   
    19, 21, 23, 25, 28, 31, 34, 37, 41, 45,   
    50, 55, 60, 66, 73, 80, 88, 97, 107, 118,   
    130, 143, 157, 173, 190, 209, 230, 253, 279, 307,   
    337, 371, 408, 449, 494, 544, 598, 658, 724, 796,   
    876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066,   
    2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358,   
    5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899,   
    15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767   
    ]; 
var state = {prevsample : null, previndex : null};

var predsample;
var index;
var step;

var diff;
var diffq;
var indexa;
var indexb;

this.decode = function (data)
{
	state.prevsample=0;   
    state.previndex=0;
	var flags = true;
	var inputArray = new Uint8Array(data);
	var outputArray = new ArrayBuffer(4 * inputArray.length);
	var output = new Int16Array(outputArray);
	var i = 0;
	var temp = null;
	while(i < inputArray.length)
	{
		 temp = ADPCMDecoder((inputArray[i] & 0xf0) >> 4);   
		 output[2 * i] = temp;
		 
		 temp = ADPCMDecoder(inputArray[i] & 0x0f); 
		 output[2 * i + 1] = temp;	
		
		 i++;
	}
	//return outputArray;
	this.postMessage({'decoded_buffer' : outputArray});
}

this.encode = function(data)
{
	state.prevsample=0;   
    state.previndex=0;
	var flags = true;
	var input = new Int16Array(data);
	var array = new ArrayBuffer(data.byteLength / 4);
	var output = new Uint8Array(array);
	var i = 0;
	while(i < output.length)
	{	
		if(flags)
		{
			temp = ADPCMEncoder(input[i]) << 4;
			flags = false;
		}
		else
		{
			flags = true;
			temp += ADPCMEncoder(input[i]) & 0x0f;
			count = (i - 1) / 2;
			output[count] = temp;
		}
		i ++;
	}
	
	if(!flags)
	{
		temp = temp & 0xf0;
		output[output.length - 1] = temp;
	}
	
	//return array;
	this.postMessage({'encoded_buffer' : array});	 
}

function ADPCMEncoder(sample)
{
	var code;
	var tempstep;
	
	predsample = state.prevsample;
	index = state.previndex;
	step = StepSizeTable[index];

	diff = sample - predsample;
	if(diff >= 0)
	{
		code = 0;
	}
	else
	{
		code = 8;
		diff = -diff;
	}
	
	tempstep = step;
	if(diff >= tempstep)
	{
		code |= 4;
		diff -= tempstep;
	}
	tempstep >>= 1;
	if(diff >= tempstep)
	{
		code |= 2;
		diff -=tempstep;
	}
	tempstep >>= 1;
	if(diff >= tempstep)
		code |= 1;
	
	diffq = step >> 3;
	if(code & 4)
		diffq += step;
	if(code & 2)
		diffq += step >> 1;
	if(code & 1)
		diffq += step >> 2;
		
	if(code & 8)
		predsample -= diffq;
	else
		predsample += diffq;
		
	if(predsample > 32767)
		predsample = 32767;
	else if(predsample < -32767)
		predsample = -32767;
		
	indexa = index;
	index += IndexTable[code];
	indexb = index;
	
	if(index < 0)
		index = 0;
	if(index > 88)
		index = 88;
		
	state.prevsample = predsample;
	state.previndex = index;
	
	var result = code & 0x0f;
	
	return (code & 0x0f);
}	

function ADPCMDecoder(inCode)
{
	predsample = state.prevsample;
	index = state.previndex;
	step = StepSizeTable[index];
	
	diffq = step >> 3;
	if(inCode & 4)
		diffq += step;
	if(inCode & 2)
		diffq += step >> 1;
	if(inCode & 1)
		diffq += step >> 2;
		
	if(inCode & 8)
		predsample -= diffq;
	else
		predsample += diffq;
		
	if(predsample > 32767)
		predsample = 32767;
	else if(predsample < -32768)
		predsample = -32768;
	
	index += IndexTable[inCode];
	if(index < 0)
		index = 0;
	if(index > 88)
		index = 88;
		
	state.prevsample = predsample;
	state.previndex = index;
	
	return predsample;
}